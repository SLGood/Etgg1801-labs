# ETGG1801.90
# Stephen Good
# Lab 01 - Hello World
# 9/6/2020

import math

firstName = "Stephen"
lastName = "Good"
opposite = 3.2
adjacent = 2

print("Lab01 created by:", firstName, lastName)

print(firstName, end= " ")

print(lastName, end= "\n")

hypotenuse = math.sqrt(opposite**2 + adjacent**2)

print("The Hypotenuse length is ", hypotenuse, "if the other sides are", opposite, "and", adjacent)

while 1:
    print("Please input values for the opposite and adjacent length to find the hypotenuse, or press enter to stop")

    opposite = input("opposite = ")
    if opposite == "":
        exit()

    adjacent = input("adjacent = ")
    if adjacent == "":
        exit()
    opposite = float(opposite)
    adjacent = float(adjacent)

    hypotenuse = math.sqrt(opposite**2 + adjacent**2)

    print("The Hypotenuse length is ", hypotenuse, "if the other sides are", opposite, "and", adjacent)





